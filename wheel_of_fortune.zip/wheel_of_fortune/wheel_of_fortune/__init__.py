from .game import start_game
from .file_handler import random_word_generator, load_record, save_record
from .decorators import timer, log_errors
