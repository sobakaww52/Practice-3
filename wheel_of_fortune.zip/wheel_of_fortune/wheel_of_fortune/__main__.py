from wheel_of_fortune.game import start_game

if __name__ == '__main__':
    start_game()

